# Resume evidence

Generated from the completed saved analysis. Values below refer to the corrected
ingestion run, not the preserved first run. No results are invented or inferred from
the simulated inventory scenario.

## Proposed entry

**Retail Demand Forecasting & Inventory Risk Analytics**

- Reduced pooled 28-day forecast WAPE by 28.9% versus a weekly seasonal-naive baseline (112.8% to 80.2%) across 20 retail products using Python, pandas and statsmodels; selected settings on three chronological validation windows.
- Audited 1,067,371 UCI transaction rows and built a DuckDB SQL and Streamlit/Plotly dashboard with product-level metrics and adjustable, explicitly simulated inventory and supplier-delay scenarios.

## Numerical claim mapping

| Claim | Exact measured value | Supporting output and location |
| --- | --- | --- |
| 28.9% relative pooled WAPE reduction | 28.864142803% | `outputs/test_overall_metrics.csv`, row `model=hw_weekly`, `relative_wape_reduction_pct` |
| Baseline pooled WAPE 112.8% | 112.798034275% | Same file, `model=seasonal_naive`, `wape` |
| Selected pooled WAPE 80.2% | 80.239848583% | Same file, `model=hw_weekly`, `wape` |
| 20 products | 20 selected product IDs | `outputs/split_manifest.json`, `selected_product_ids`; `outputs/product_metadata.csv` |
| 28-day forecast horizon | 28 days at each fixed origin | `outputs/split_manifest.json`, each split's `horizon_days`; `outputs/test_predictions.csv`, `horizon_day` |
| Three validation windows | validation_1, validation_2, validation_3 | `outputs/split_manifest.json`, `splits`; `outputs/validation_window_metrics.csv` |
| 1,067,371 audited raw rows | 1067371 | `outputs/data_audit.json`, `raw_rows` and sum of both `sheets[].raw_rows` |
| 10/20 products beating baseline | 10/20 (50.0%) | `outputs/test_overall_metrics.csv`, chosen row, `products_beating_baseline`, `comparable_products`, `products_beating_baseline_pct`; verify with `outputs/test_product_metrics.csv` |
| Selected MAE | 68.809968723 units/product-day | `outputs/test_overall_metrics.csv`, chosen row, `mae` |
| Cross-sheet replicas removed | 22523 | `outputs/data_audit.json`, `duplicate_rows_removed`, priority `cross_sheet_replica` count |
| Initial training history | 626 calendar days | `outputs/split_manifest.json`, first split, `training_days` |

Relative reduction is computed from the pooled WAPE values, not from mean product
WAPE and not from `100 − WAPE`. This is a historical portfolio benchmark, not an
operational improvement claim. Every displayed percentage is rounded from saved
values; do not substitute validation performance for final-test results.

## Technology evidence

| Technology | Executed implementation |
| --- | --- |
| Python / pandas | `src/data.py`, `src/metrics.py`; actual environment in `outputs/run_manifest.json` |
| statsmodels | `src/forecast.py`; forecasts in `outputs/test_predictions.csv` and validation predictions |
| DuckDB SQL | `src/inventory.py`, three `sql/*.sql` files; saved query outputs and regenerated database |
| Streamlit / Plotly | `app.py`; AppTest evidence in `outputs/test-results.xml` and browser screenshots |

## Transparency and constraints

The first run retained overlapping-sheet replicas. The corrected rerun kept the
original validation-selected `hw_weekly` family and its settings fixed after
the final test had already been seen. `outputs/correction_record.json` explains the
repair and `outputs/before_overlap_correction/` preserves original measurements.
This is disclosed in the README; do not claim the corrected rerun was a newly
untouched holdout. Eligibility is recomputed solely from corrected pre-validation
sales, never from performance. The configuration and model settings were not tuned
to improve test results.

The inventory figures are deterministic simulations. Do not claim avoided stock-outs,
cost savings, inventory reductions, risk-probability calibration, production deployment
or Prophet usage. No additional numerical resume claims are proposed.
