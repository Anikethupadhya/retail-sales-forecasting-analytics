# Interview guide

## Problem and target

Forecast daily **positive units sold** for a reproducibly chosen cohort of 20
regular, high-volume products. Predict a complete 28-day horizon from one origin.
Aggregate countries because the business question is product-level sales rather
than customer or geographic forecasting. Sales are observable; unconstrained
demand and stock-out losses are not available in this dataset.

## Baseline and candidates

The weekly seasonal-naive baseline repeats the last seven observed calendar days
four times. It never consumes actuals from the 28-day horizon. Candidates are
simple exponential smoothing, additive weekly Holt-Winters without trend, and
additive weekly Holt-Winters with a damped additive trend. Their coefficients are
optimized on each training window, while the model family is chosen on validation.
Weekly additive seasonality supports zero sales; multiplicative models would not.
Forecasts are clipped at zero by a rule set before any evaluation. Failed fits and
optimizer failures use the baseline as a prespecified operational fallback, with
events retained rather than silently dropping difficult products.

## Selection and leakage prevention

Three consecutive, non-overlapping 28-day validation windows use expanding
training histories. The following 28 days are the final test. Eligibility and
ranking use only observations before the first validation window: early first
sale, regular sales over the initial window and recent 90 days, then descending
initial unit volume with deterministic ID tie-breaking. The full selection audit
and exact dates are in `outputs/split_manifest.json` and `product_eligibility.csv`.
No product is selected for its final-test performance. Descriptions and simulated
inventory assumptions also use the initial training period.

The global model family minimizes pooled validation WAPE. Baseline wins exact
ties according to configured model order. `frozen_selection.json` is written
before the final-test evaluation call. Only the selected family and baseline are
tested. Hyperparameters and products are not changed after seeing the test. A
test replaces future actuals with very large values and verifies identical
predictions for all four model families.

## Cleaning decisions

Keep missing customer IDs because the target is product sales. The two workbook
sheets overlap in December 2010. Remove exact cross-sheet replicas by matching
every original field and the within-sheet occurrence number; this preserves
within-sheet multiplicities. Keep repeated invoice lines within each sheet
because there is no unique line ID or evidence of ingestion errors.
Audit missing descriptions but retain valid identified merchandise. Exclude
invalid dates, missing invoice/product IDs, cross-sheet replicas, cancellations, nonpositive quantities,
non-merchandise codes, nonpositive prices and the final potentially truncated
calendar day. Merchandise uses five digits followed by up to two letters; this
explicit heuristic can exclude unconventional genuine products. Price exclusions
avoid counting zero-priced adjustments as commercial sales. Priority exclusion
counts reconcile to raw rows; independent flags overlap. Returns/cancellations
are saved separately and are not netted against the positive-sales target.

Daily calendar grids include zeros for absent records, including closure days and
short pre-listing periods. This assumes the extract has transaction coverage;
it cannot distinguish no sales, missing records, closure or stock-out. No
outlier trimming is performed, so genuine bulk orders can dominate errors.

## Explaining metrics

MAE has units of units per product-day. WAPE is
`100 × sum(abs(actual − prediction)) / sum(abs(actual))`. Pooled WAPE aggregates
errors and actual units across products and horizons, giving more weight to
higher-volume products. Mean per-product WAPE gives each product equal weight;
both are saved and labeled. A zero actual denominator produces an undefined
WAPE, saved as blank/null. Relative reduction is
`100 × (baseline WAPE − selected WAPE) / baseline WAPE`; it is undefined if the
baseline WAPE is zero. Negative reductions stay negative. Product wins require
strictly lower WAPE and comparable defined denominators; the count and percentage
use only comparable products. **100 minus WAPE is not accuracy.**

## SQL and scenario interpretation

DuckDB stores daily sales, forecasts, product metadata and simulated supplier and
inventory assumptions. Standalone SQL demonstrates aggregation, keyed joins,
`ROW_NUMBER` and cumulative `SUM` windows. Sum predictions over each product's
supplier lead time, subtract available scenario inventory and flag positive
shortfall. Lead times never exceed the saved 28-day forecast horizon.

Base lead times cycle from 5–11 days over sorted product IDs. Stock is rounded
from seven days of initial mean sales multiplied by a cycling 0.75, 1.00 or 1.25
factor. These deterministic numbers are illustrative, not estimates of real
inventory or suppliers. The dashboard changes delay, stock multiplier and extra
units without fitting models. The scenario is retrospective at the final-test
origin. It assumes no intervening deliveries and has no safety-stock or service
level calibration. Flags are replenishment indicators, not stock-out probabilities.

## What to say about results

Use the actual benchmark in the README and numerical evidence in
`docs/resume-evidence.md`. Validation gains can fail to generalize; report the
final test even if it is worse. Explain the pooled versus per-product tradeoff and
that a small high-volume cohort near the holiday peak is not the full catalogue.
Do not claim avoided stock-outs, cost savings or operational deployment.

The first executed run retained cross-sheet duplicates. On recognizing the
overlap, ingestion was corrected and the pipeline rerun with the **original
validation-selected model family fixed**. No model was changed in response to
test performance. The original outputs and correction record are preserved in
`outputs/before_overlap_correction/` and `outputs/correction_record.json`. The
corrected final-test measurement is therefore a rerun of an already observed
holdout after a documented data repair; it is not a newly untouched experiment.

## Limits and a defensible next experiment

There are no observed inventory levels, supplier deliveries, promotion flags or
lost-sales labels. The 28-day final test is one historical holiday-season period,
not evidence of year-round robustness. Demand can be intermittent and wholesale
bulk orders produce large spikes. Repeated lines and zero-filled days are explicit
measurement choices. No prediction intervals or calibrated risk probabilities
are supplied. A future experiment should prespecify new holdout dates and compare
models on a broader cohort; do not reuse this final test for tuning. Prophet is
deferred as an optional extension after this completed core benchmark.
