"""Read saved results; interactive inventory calculations run only DuckDB SQL."""
import json

import duckdb
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from src.common import OUT
from src.inventory import scenario

st.set_page_config(page_title="Retail Demand Analytics", page_icon="📦", layout="wide")
st.title("Retail Demand Forecasting & Inventory Risk Analytics")
st.caption("UCI Online Retail II · Daily positive merchandise units · Fixed-origin 28-day benchmark")
if not (OUT / "run_manifest.json").exists():
    st.info("Run python -m src.pipeline to generate the saved analysis first.")
    st.stop()


@st.cache_data
def load_outputs():
    frames = {}
    for name in ["daily_sales", "product_metadata", "validation_predictions", "test_predictions",
                 "test_overall_metrics", "test_product_metrics", "validation_overall_metrics"]:
        frames[name] = pd.read_csv(OUT / f"{name}.csv", dtype={"product_id": str})
    for name in ["daily_sales", "validation_predictions", "test_predictions"]:
        frames[name]["date"] = pd.to_datetime(frames[name].date)
    for name in ["data_audit", "split_manifest", "frozen_selection", "run_manifest", "model_events"]:
        frames[name] = json.loads((OUT / f"{name}.json").read_text())
    return frames


d = load_outputs()
chosen = d["frozen_selection"]["selected_model"]
meta = d["product_metadata"].set_index("product_id")
pid = st.sidebar.selectbox("Product", meta.index.tolist(), format_func=lambda p: f"{p} · {meta.loc[p, 'description']}")
st.sidebar.markdown("### Simulated inventory controls")
delay = st.sidebar.slider("Supplier delay (days)", 0, 17, 0)
multiplier = st.sidebar.slider("Inventory (% of simulated starting stock)", 0, 200, 100, 10) / 100
extra = st.sidebar.number_input("Additional inventory units per product", min_value=0, value=0, step=25)
st.sidebar.caption("Base lead times: 5–11 days. Delay is capped so total lead time stays within 28 days.")
st.sidebar.caption("Stock = 7 × initial-training mean daily units × a deterministic 0.75, 1.00 or 1.25 factor, rounded to units.")

test_metrics = d["test_overall_metrics"].set_index("model")
baseline = test_metrics.loc["seasonal_naive"]
selected = test_metrics.loc[chosen]
cols = st.columns(4)
cols[0].metric("Baseline pooled WAPE", f"{baseline.wape:.2f}%")
cols[1].metric("Selected pooled WAPE", f"{selected.wape:.2f}%")
cols[2].metric("Relative WAPE reduction", f"{selected.relative_wape_reduction_pct:+.2f}%")
cols[3].metric("Products beating baseline", f"{int(selected.products_beating_baseline)}/{int(selected.comparable_products)}")
st.caption(f"Measured final test · Selected approach: {chosen} · Lower WAPE is better. Reduction may be negative; WAPE is not accuracy.")
st.caption("Cross-sheet duplication was corrected after the first test run; the original validation-selected model family and cohort were preserved. See the README for the correction record.")

history_tab, metrics_tab, inventory_tab, audit_tab = st.tabs(["Sales & forecasts", "Benchmark results", "Inventory scenarios", "Data & methods"])
with history_tab:
    st.subheader(f"{pid} — {meta.loc[pid, 'description']}")
    hist = d["daily_sales"].query("product_id == @pid")
    first_sale = meta.loc[pid, "first_sale"]
    st.write(f"Calendar coverage: {hist.date.min():%Y-%m-%d} to {hist.date.max():%Y-%m-%d}. Initial-training first sale: {first_sale[:10]}. {int(hist.units.gt(0).sum())} days with observed positive sales.")
    lookback = st.radio("History shown", ["Last 180 days", "Full history"], horizontal=True)
    visible = hist if lookback == "Full history" else hist[hist.date.ge(hist.date.max() - pd.Timedelta(days=180))]
    fig = go.Figure(go.Scatter(x=visible.date, y=visible.units, name="Observed positive sales", line={"color": "#54677f", "width": 1.4}))
    colors = {"seasonal_naive": "#e28c28", chosen: "#147d92"}
    all_predictions = pd.concat([d["validation_predictions"], d["test_predictions"]])
    for model in list(dict.fromkeys(["seasonal_naive", chosen])):
        label = "Weekly seasonal baseline" if model == "seasonal_naive" else "Selected weekly smoothing"
        for i, (split, part) in enumerate(all_predictions.query("product_id == @pid and model == @model").groupby("split", sort=False)):
            fig.add_trace(go.Scatter(x=part.date, y=part.prediction, name=label,
                                    legendgroup=model, showlegend=i == 0,
                                    hovertemplate=f"{split}<br>Date: %{{x}}<br>Forecast units: %{{y:.1f}}<extra>{label}</extra>",
                                    line={"color": colors[model], "dash": "dash" if model == "seasonal_naive" else "solid"}))
    for split in d["split_manifest"]["splits"]:
        fig.add_vrect(x0=split["forecast_start"], x1=str(pd.Timestamp(split["forecast_end"]) + pd.Timedelta(days=1)),
                      fillcolor="#e6b361" if split["stage"] == "test" else "#69a9bc", opacity=0.10, line_width=0)
        fig.add_annotation(x=split["forecast_start"], y=1, yref="paper", text=split["split"].replace("_", " "), showarrow=False, xanchor="left")
    fig.update_layout(height=480, xaxis_title="Calendar date", yaxis_title="Positive units sold", legend={"orientation": "h", "y": -0.2}, margin={"t": 35})
    st.plotly_chart(fig, width="stretch")
    st.caption("Blue shading: validation windows. Amber shading: final test. Each line uses a single forecast origin and no within-horizon actuals. These are historical evaluation forecasts.")
    per = d["test_product_metrics"].query("product_id == @pid")
    st.dataframe(per[["model", "mae", "wape", "baseline_wape", "relative_wape_reduction_pct"]], hide_index=True, width="stretch")

with metrics_tab:
    st.subheader("Untouched final test")
    st.dataframe(d["test_overall_metrics"], hide_index=True, width="stretch")
    st.subheader("Validation used for selection")
    st.dataframe(d["validation_overall_metrics"], hide_index=True, width="stretch")
    st.caption("Pooled WAPE = 100 × total absolute error / total absolute observed units. Mean product WAPE weights products equally and differs from pooled WAPE. Undefined denominators are saved as null/blank; ties do not count as wins.")
    st.subheader("Final-test performance by product")
    st.dataframe(d["test_product_metrics"], hide_index=True, width="stretch")
    st.download_button("Download final-test metrics", (OUT / "test_product_metrics.csv").read_bytes(), "test_product_metrics.csv", "text/csv")

with inventory_tab:
    st.subheader("Simulated replenishment indicators")
    st.info("Historical scenario at the final-test forecast origin. Inventory and supplier lead times are simulated, not observed. Flags are not stock-out probabilities or evidence of savings.")
    with duckdb.connect(str(OUT / "retail.duckdb"), read_only=True) as con:
        table = scenario(con, delay, multiplier, extra)
    short = st.columns(3)
    short[0].metric("Flagged products", int(table.replenishment_flag.sum()))
    short[1].metric("Total scenario shortfall", f"{table.scenario_shortfall_units.sum():,.1f} units")
    short[2].metric("Supplier delay", f"{delay} days")
    display_columns = ["product_id", "description", "lead_days", "scenario_inventory_units",
                       "forecast_lead_time_units", "scenario_shortfall_units", "replenishment_flag"]
    st.dataframe(table[display_columns], hide_index=True, width="stretch", column_config={
        "product_id": st.column_config.TextColumn("Product", width="small"),
        "description": st.column_config.TextColumn("Description", width="medium"),
        "lead_days": st.column_config.NumberColumn("Lead days", format="%d", width="small"),
        "scenario_inventory_units": st.column_config.NumberColumn("Stock units", format="%.1f", width="small"),
        "forecast_lead_time_units": st.column_config.NumberColumn("Lead-time sales", format="%.1f", width="small"),
        "scenario_shortfall_units": st.column_config.NumberColumn("Shortfall units", format="%.1f", width="small"),
        "replenishment_flag": st.column_config.CheckboxColumn("Replenish", width="small"),
    })
    st.caption(f"Scenario origin: {pd.Timestamp(table.scenario_origin.iloc[0]):%Y-%m-%d}. Full input assumptions and coverage columns are included in the download.")
    st.download_button("Download current scenario", table.to_csv(index=False), "inventory_scenario.csv", "text/csv")
    st.caption("Shortfall = max(forecast units over lead time − scenario inventory, 0). Assumes no intervening deliveries or safety stock; fractional forecasts are retained. Inventory controls apply to every product.")

with audit_tab:
    audit = d["data_audit"]
    st.subheader("Source coverage and cleaning")
    st.write(f"{audit['raw_rows']:,} raw rows across {len(audit['sheets'])} sheets; {audit['retained_rows']:,} retained merchandise rows before product selection.")
    st.write(audit["source"])
    st.dataframe(pd.DataFrame(audit["sheets"]), hide_index=True)
    st.dataframe(pd.DataFrame(list(audit["exclusive_exclusion_counts_in_priority_order"].items()), columns=["Exclusion (priority order)", "Rows"]), hide_index=True)
    st.write(audit["duplicate_policy"])
    st.write(audit["zero_sales_assumption"])
    st.warning("Observed sales proxy demand. The source has no inventory history and cannot reveal lost sales during stock-outs. This small, high-volume cohort and holiday-period test do not establish performance across the full catalogue.")
    st.dataframe(pd.DataFrame(d["split_manifest"]["splits"]), hide_index=True)
    st.json(d["frozen_selection"])
    st.write(f"Recorded model events: {len(d['model_events'])}. Full details are in outputs/model_events.json.")
    with st.expander("Audit and provenance"):
        st.json(audit)
