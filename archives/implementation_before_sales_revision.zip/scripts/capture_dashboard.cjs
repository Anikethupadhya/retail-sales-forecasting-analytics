// Development utility; requires Playwright in the supplied runtime or NODE_PATH.
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
(async () => {
  const browser = await chromium.launch({headless: true, channel: 'msedge'});
  try {
  const page = await browser.newPage({viewport: {width: 1600, height: 1350}, deviceScaleFactor: 1});
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('http://localhost:8501', {waitUntil: 'networkidle'});
  await page.getByRole('tab', {name: 'Sales & forecasts', exact: true}).waitFor();
  await page.locator('[data-testid="stPlotlyChart"]').waitFor();
  await page.screenshot({path: 'docs/screenshots/dashboard-sales.png', fullPage: true});
  await page.getByRole('tab', {name: 'Inventory scenarios', exact: true}).click();
  await page.getByText('Simulated replenishment indicators', {exact: true}).waitFor();
  await page.screenshot({path: 'docs/screenshots/dashboard-inventory.png', fullPage: true});
  fs.writeFileSync('outputs/browser_smoke.json', JSON.stringify({url:'http://localhost:8501', screenshots:2, page_errors:errors}, null, 2));
  if (errors.length) process.exitCode = 1;
  } finally {
    await browser.close();
  }
})().catch(e => { console.error(e); process.exitCode = 1; });
