"""Generate portfolio documentation solely from saved measured outputs."""
import json

import pandas as pd

from .common import ROOT, OUT


def table(frame, columns):
    lines = ["| " + " | ".join(columns) + " |", "| " + " | ".join(["---"] * len(columns)) + " |"]
    for _, row in frame.iterrows():
        cells = []
        for column in columns:
            value = row[column]
            cells.append(f"{value:.2f}" if isinstance(value, float) else str(value))
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


def generate():
    audit = json.loads((OUT / "data_audit.json").read_text())
    manifest = json.loads((OUT / "split_manifest.json").read_text())
    freeze = json.loads((OUT / "frozen_selection.json").read_text())
    run = json.loads((OUT / "run_manifest.json").read_text())
    events = json.loads((OUT / "model_events.json").read_text())
    test = pd.read_csv(OUT / "test_overall_metrics.csv")
    validation = pd.read_csv(OUT / "validation_overall_metrics.csv")
    selected = test[test.model.eq(freeze["selected_model"])].iloc[0]
    baseline = test[test.model.eq("seasonal_naive")].iloc[0]
    count = len(manifest["selected_product_ids"])
    wins = int(selected.products_beating_baseline)
    gain = selected.relative_wape_reduction_pct
    if gain > 0:
        bullet1 = f"Reduced pooled 28-day forecast WAPE by {gain:.1f}% versus a weekly seasonal-naive baseline ({baseline.wape:.1f}% to {selected.wape:.1f}%) across {count} retail products using Python, pandas and statsmodels; selected settings on three chronological validation windows."
    else:
        bullet1 = f"Benchmarked fixed-origin 28-day sales forecasts for {count} retail products with Python, pandas and statsmodels; reported {selected.wape:.1f}% pooled final-test WAPE versus {baseline.wape:.1f}% for a weekly seasonal-naive baseline after three chronological validation windows."
    bullet2 = f"Audited {audit['raw_rows']:,} UCI transaction rows and built a DuckDB SQL and Streamlit/Plotly dashboard with product-level metrics and adjustable, explicitly simulated inventory and supplier-delay scenarios."
    splits = pd.DataFrame(manifest["splits"])
    exclusions = pd.DataFrame(list(audit["exclusive_exclusion_counts_in_priority_order"].items()), columns=["exclusion", "rows"])
    n_fallback = sum(e["status"] != "ok" for e in events)
    n_warning = sum(bool(e.get("warnings")) for e in events)
    n_clip = sum(e.get("negative_predictions_clipped", 0) for e in events)
    inventory = pd.read_csv(OUT / "inventory_scenario.csv")
    (ROOT / "README.md").write_text(f'''# Retail Demand Forecasting & Inventory Risk Analytics

A reproducible Python portfolio project that forecasts daily positive merchandise
units, benchmarks 28-day fixed-origin predictions, and explores simulated
replenishment scenarios in DuckDB SQL and a Streamlit dashboard.

**Measured result:** the validation-selected `{selected.model}` approach achieved
**{selected.wape:.2f}% pooled final-test WAPE**, versus **{baseline.wape:.2f}%** for the
weekly seasonal-naive baseline: **{gain:.2f}% relative WAPE reduction**.
It beat the baseline on **{wins}/{count} products ({selected.products_beating_baseline_pct:.0f}%)**.
The absolute errors remain large. These figures describe historical observed-sales
forecast performance, not accuracy, operational savings or calibrated inventory risk.

## Reproduce

Tested with Python {run['python']} on Windows. Run these commands from this folder:

```powershell
python -m venv .venv
.\\.venv\\Scripts\\python -m pip install -r requirements.txt
.\\.venv\\Scripts\\python -m src.pipeline
.\\.venv\\Scripts\\python -m pytest -q --junitxml=outputs/test-results.xml
.\\.venv\\Scripts\\python -m streamlit run app.py --server.headless true --browser.gatherUsageStats false
```

**The full analysis command is `python -m src.pipeline`** (use the virtual environment's
Python). It downloads the official workbook if needed, audits it, selects products,
validates candidates, evaluates the frozen approach, creates saved outputs and the
DuckDB database, and regenerates this README and the evidence document from measured
results. The latest measured execution took {run['duration_seconds']:.1f} seconds,
with runtime varying by hardware and first-run workbook reads. Subsequent runs use
a raw-file-checksum-keyed Parquet cache. The dashboard only reads saved results and
runs scenario SQL; it does not train models. Open http://localhost:8501.

If source download fails, follow [exact manual instructions](docs/data-download.md).
`data/raw/`, read caches and the generated DuckDB binary stay outside Git. Rebuild
the database by running the pipeline after cloning. Dependencies and their installed
transitive versions are pinned in `requirements.txt`; environment provenance is saved.

## Source and audit

[Chen, D. (2012), Online Retail II, UCI](https://archive.ics.uci.edu/dataset/502/online+retail+ii),
[DOI:10.24432/C5CG6D](https://doi.org/10.24432/C5CG6D), CC BY 4.0.
The actual workbook contains **{audit['raw_rows']:,} rows** across sheets
`Year 2009-2010` ({audit['sheets'][0]['raw_rows']:,}) and `Year 2010-2011`
({audit['sheets'][1]['raw_rows']:,}). Raw timestamps range from
**{audit['raw_date_min']}** to **{audit['raw_date_max']}**. Actual columns are
`Invoice`, `StockCode`, `Description`, `Quantity`, `InvoiceDate`, `Price`,
`Customer ID`, `Country`. Both sheets are inspected explicitly.

SHA-256: `{audit['sha256']}`.

Exclusive exclusions are counted in this priority order, so they reconcile:

{table(exclusions, ['exclusion', 'rows'])}

**{audit['retained_rows']:,} merchandise rows remain** before selecting the cohort.
The workbook has {audit['exact_duplicate_rows_beyond_first']:,} exact repeated rows
beyond their first occurrence. Remove **{audit['duplicate_rows_removed']:,} cross-sheet
replicas** in the overlapping December 2010 export interval, matching every original
field plus its within-sheet occurrence number. Retain **{audit['within_sheet_repeated_rows_retained']:,}
within-sheet repeated lines**: no unique line ID proves these are errors.
Missing customer IDs alone do not exclude sales; **{audit['retained_missing_customer_id_rows']:,} retained
rows have no customer ID**. Returns/cancellations and all excluded rows are preserved
separately in local compressed CSV audit extracts with sheet and Excel row references.

Merchandise IDs match five digits with up to two trailing letters, explicitly
excluding charges such as postage, discounts and manual adjustments. This heuristic
may also exclude unusual genuine merchandise codes. Nonpositive prices are excluded
as noncommercial/adjustment records. Missing descriptions are audited, not an automatic
exclusion. All countries are pooled. No outlier trimming is applied.

The latest timestamp is midday on 2011-12-09, so that entire potentially incomplete
day is excluded. Daily grids run from {audit['daily_grid_start']} to {audit['daily_grid_end']}.
Absent product-date records become zero observed sales, including closures and short
pre-listing intervals. Missing transactions, no demand and stock-outs cannot be distinguished.
Positive sales are a proxy for demand; the workbook does not reveal lost sales.

## Cohort, forecasts and model selection

Select {count} products using only data strictly before **{manifest['selection_cutoff_exclusive']}**:
first sale within 90 days of the grid start, sales on at least 25% of initial calendar
days and 30% of the last 90 days. Rank eligible products by initial positive units,
breaking ties by ascending ID. Save all eligibility decisions and selected IDs.
The initial training window contains **{manifest['splits'][0]['training_days']} days**.

{table(splits, ['split', 'train_start', 'train_end', 'forecast_start', 'forecast_end', 'training_days'])}

The seasonal-naive baseline repeats the origin's last seven calendar-day observations
throughout the horizon. Candidates are simple exponential smoothing (`ses`), additive
weekly seasonality without trend (`hw_weekly`), and additive weekly seasonality with
damped additive trend (`hw_damped_weekly`). Statsmodels estimates initialization and
optimizes smoothing parameters on each available training history. Weekly models use
`use_brute=False`. Forecasts are prespecified to be clipped at zero. Exceptions,
nonfinite forecasts and optimizer failures fall back to the baseline, with events saved.

Choose one global model family by minimum pooled WAPE over the three validation
windows, with baseline preferred on ties. Each model sees only dates through its
origin. No actual observation inside its forecast horizon influences later predictions.
The frozen selection artifact is written before final-test prediction. Only the chosen
family and baseline receive final-test evaluation. Candidate failures and negative
improvements are preserved. This run recorded {len(events)} model events: {n_fallback}
fallback fits, {n_warning} fits with warnings, and {n_clip} individual predictions clipped at zero.

**Data correction disclosure:** the first run retained replicas across overlapping
workbook sheets. After discovering the overlap, ingestion was repaired and rerun
with the **original validation-selected family and all model settings fixed**.
The first test was already observed before that repair; the corrected figures are
not a newly untouched holdout. Original measured outputs are preserved in
`outputs/before_overlap_correction/`, with rationale in `outputs/correction_record.json`.
No model family was chosen or tuned based on final-test improvement.

## Actual benchmark results

Validation (all three windows pooled, 1,680 product-days per model):

{table(validation, ['model', 'mae', 'wape', 'relative_wape_reduction_pct', 'products_beating_baseline', 'mean_product_wape'])}

Final test (560 product-days per evaluated model):

{table(test, ['model', 'mae', 'wape', 'relative_wape_reduction_pct', 'products_beating_baseline', 'mean_product_wape'])}

WAPE = `100 × sum(abs(actual − prediction)) / sum(abs(actual))`.
MAE is units per product-day. `wape` in the overall table is **pooled WAPE**;
`mean_product_wape` is the arithmetic mean of defined per-product WAPEs.
Relative reduction = `100 × (baseline WAPE − model WAPE) / baseline WAPE`.
Zero actual denominators yield null/blank WAPE; zero baseline WAPE yields null
relative reduction. Product wins require strictly lower WAPE, using only comparable
defined denominators. WAPE can exceed 100%; **100 minus WAPE is not accuracy**.
Validation and final-test predictions, pooled metrics and product metrics are separate.

## SQL and inventory scenarios

DuckDB tables: `daily_sales`, `forecasts`, `product_metadata`, `inventory_assumptions`.
Standalone [SQL](sql/) demonstrates aggregation, joins, `ROW_NUMBER`, rolling seven-day
sales and cumulative forecast windows. Scenario controls are bound SQL parameters.

**Simulated assumptions:** sorted product IDs deterministically receive 5–11 day
base lead times and starting stock equal to rounded `7 × initial mean daily units × factor`,
with factors cycling through 0.75, 1.00 and 1.25. Initial means use only pre-validation
data. Users can add 0–17 days supplier delay, vary stock by 0–200% and add units.
Total lead times remain within 28 days. Forecast sales over lead time minus scenario
stock, floored at zero, defines shortfall. A positive shortfall triggers a scenario
replenishment indicator. No intervening receipts or safety stock are assumed.

The default scenario flags **{int(inventory.replenishment_flag.sum())}/{count} products**.
This is a retrospective scenario at the final-test forecast origin, not a current
operational forecast. **Stock and supplier inputs are simulated**, not measured.
Flags are not calibrated stock-out probabilities and do not establish actual savings.

## Dashboard

Product selection, coverage, history, shaded evaluation periods, baseline versus
selected forecasts, overall and product metrics, source audit, and responsive inventory
controls all use saved outputs. The screenshot images below show the tested default
state. Measured forecasting results and simulated inventory are labeled separately.

![Measured sales and forecasts](docs/screenshots/dashboard-sales.png)
![Simulated inventory scenarios](docs/screenshots/dashboard-inventory.png)

## Verification and repository map

`python -m pytest -q --junitxml=outputs/test-results.xml` checks chronological split
boundaries, weekly baseline repetition, future-actual perturbations for all model
families, exact cross-sheet occurrence matching, metric arithmetic and zero denominators,
pooled versus mean WAPE, hand-calculated SQL scenarios and horizon limits, saved-output
reconciliation, and Streamlit load/product/delay/inventory interactions.
The browser smoke result and screenshots are recorded separately in
`outputs/browser_smoke.json`. Screenshots use a development-only Playwright utility
with local Edge; Playwright is not a dashboard runtime dependency.

- `config.json`: prespecified data, eligibility, horizon and model rules.
- `src/`: acquisition/audit, forecasting, metrics, SQL inventory, orchestration and reporting.
- `sql/`: three independently readable query files.
- `app.py`: dashboard reading saved outputs; `tests/`: meaningful checks.
- `outputs/`: audit, selection/split manifests, forecasts, metrics, assumptions and execution evidence.
- `docs/interview-guide.md`: decisions and explanations for interviews.
- `docs/resume-evidence.md`: numerical claims mapped to measured artifacts.

Raw data, caches, customer-level audit extracts and the generated database are ignored.
No remote repository, cloud service or public deployment was created.

## Limitations and extensions

This is a high-volume cohort, not the full product catalogue, and the final holdout
falls near a holiday peak. Substantial product-level errors and only {wins}/{count} wins
limit the pooled headline. There are no actual stock levels, deliveries, promotions,
lost-sales labels or calibrated forecast intervals. Returns are separate rather than
net sales. Wholesale spikes remain in the target. Zero-filled days and the merchandise
code heuristic are measurement assumptions. The ingestion repair is disclosed above.
The optional Prophet extension is deferred; no LSTM, Docker, paid API or forecasting
agent is used. A future comparison should prespecify new holdouts before testing.

## Proposed resume entry

**Retail Demand Forecasting & Inventory Risk Analytics**

- {bullet1}
- {bullet2}

These are portfolio benchmark claims; do not describe the inventory scenarios as
operational outcomes. See the [claim-by-claim evidence](docs/resume-evidence.md).
''', encoding="utf-8")
    (ROOT / "docs/resume-evidence.md").write_text(f'''# Resume evidence

Generated from the completed saved analysis. Values below refer to the corrected
ingestion run, not the preserved first run. No results are invented or inferred from
the simulated inventory scenario.

## Proposed entry

**Retail Demand Forecasting & Inventory Risk Analytics**

- {bullet1}
- {bullet2}

## Numerical claim mapping

| Claim | Exact measured value | Supporting output and location |
| --- | --- | --- |
| {gain:.1f}% relative pooled WAPE reduction | {gain:.9f}% | `outputs/test_overall_metrics.csv`, row `model={selected.model}`, `relative_wape_reduction_pct` |
| Baseline pooled WAPE {baseline.wape:.1f}% | {baseline.wape:.9f}% | Same file, `model=seasonal_naive`, `wape` |
| Selected pooled WAPE {selected.wape:.1f}% | {selected.wape:.9f}% | Same file, `model={selected.model}`, `wape` |
| {count} products | {count} selected product IDs | `outputs/split_manifest.json`, `selected_product_ids`; `outputs/product_metadata.csv` |
| 28-day forecast horizon | 28 days at each fixed origin | `outputs/split_manifest.json`, each split's `horizon_days`; `outputs/test_predictions.csv`, `horizon_day` |
| Three validation windows | validation_1, validation_2, validation_3 | `outputs/split_manifest.json`, `splits`; `outputs/validation_window_metrics.csv` |
| {audit['raw_rows']:,} audited raw rows | {audit['raw_rows']} | `outputs/data_audit.json`, `raw_rows` and sum of both `sheets[].raw_rows` |
| {wins}/{count} products beating baseline | {wins}/{int(selected.comparable_products)} ({selected.products_beating_baseline_pct:.1f}%) | `outputs/test_overall_metrics.csv`, chosen row, `products_beating_baseline`, `comparable_products`, `products_beating_baseline_pct`; verify with `outputs/test_product_metrics.csv` |
| Selected MAE | {selected.mae:.9f} units/product-day | `outputs/test_overall_metrics.csv`, chosen row, `mae` |
| Cross-sheet replicas removed | {audit['duplicate_rows_removed']} | `outputs/data_audit.json`, `duplicate_rows_removed`, priority `cross_sheet_replica` count |
| Initial training history | {manifest['splits'][0]['training_days']} calendar days | `outputs/split_manifest.json`, first split, `training_days` |

Relative reduction is computed from the pooled WAPE values, not from mean product
WAPE and not from `100 − WAPE`. This is a historical portfolio benchmark, not an
operational improvement claim. Every displayed percentage is rounded from saved
values; do not substitute validation performance for final-test results.

## Technology evidence

| Technology | Executed implementation |
| --- | --- |
| Python / pandas | `src/data.py`, `src/metrics.py`; actual environment in `outputs/run_manifest.json` |
| statsmodels | `src/forecast.py`; forecasts in `outputs/test_predictions.csv` and validation predictions |
| DuckDB SQL | `src/inventory.py`, three `sql/*.sql` files; saved query outputs and regenerated database |
| Streamlit / Plotly | `app.py`; AppTest evidence in `outputs/test-results.xml` and browser screenshots |

## Transparency and constraints

The first run retained overlapping-sheet replicas. The corrected rerun kept the
original validation-selected `{selected.model}` family and its settings fixed after
the final test had already been seen. `outputs/correction_record.json` explains the
repair and `outputs/before_overlap_correction/` preserves original measurements.
This is disclosed in the README; do not claim the corrected rerun was a newly
untouched holdout. Eligibility is recomputed solely from corrected pre-validation
sales, never from performance. The configuration and model settings were not tuned
to improve test results.

The inventory figures are deterministic simulations. Do not claim avoided stock-outs,
cost savings, inventory reductions, risk-probability calibration, production deployment
or Prophet usage. No additional numerical resume claims are proposed.
''', encoding="utf-8")


if __name__ == "__main__":
    generate()
