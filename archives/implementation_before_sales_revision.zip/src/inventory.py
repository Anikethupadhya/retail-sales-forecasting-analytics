import duckdb
import pandas as pd

from .common import ROOT, OUT


def scenario(connection, delay=0, multiplier=1.0, extra_units=0.0):
    max_base = connection.execute("SELECT MAX(base_lead_days) FROM inventory_assumptions").fetchone()[0]
    horizon = connection.execute("SELECT MAX(horizon_day) FROM forecasts WHERE stage='test' AND selected").fetchone()[0]
    if not 0 <= delay <= horizon - max_base or multiplier < 0 or extra_units < 0:
        raise ValueError("Scenario controls must be nonnegative and lead times within the forecast horizon")
    return connection.execute((ROOT / "sql/inventory_scenario.sql").read_text(), [delay, multiplier, extra_units]).df()


def build_database(daily, metadata, forecasts, manifest):
    # Assumptions depend only on pre-validation sales and stable product ordering.
    cutoff = pd.Timestamp(manifest["selection_cutoff_exclusive"])
    initial = daily[daily.date.lt(cutoff)].groupby("product_id").units.mean()
    assumptions = []
    for i, pid in enumerate(sorted(metadata.product_id)):
        factor = [0.75, 1.0, 1.25][i % 3]
        assumptions.append({"product_id": pid, "base_lead_days": 5 + i % 7,
                            "base_inventory_units": float(round(initial[pid] * 7 * factor)),
                            "inventory_factor": factor, "initial_mean_daily_units": float(initial[pid]),
                            "assumption_type": "SIMULATED: seven days initial mean sales times deterministic factor"})
    inventory_assumptions = pd.DataFrame(assumptions)
    inventory_assumptions.to_csv(OUT / "inventory_assumptions.csv", index=False)
    with duckdb.connect(str(OUT / "retail.duckdb")) as con:
        for name, frame in [("daily_sales", daily), ("product_metadata", metadata), ("forecasts", forecasts),
                            ("inventory_assumptions", inventory_assumptions)]:
            con.register("input_frame", frame)
            con.execute(f"CREATE OR REPLACE TABLE {name} AS SELECT * FROM input_frame")
            con.unregister("input_frame")
        scenario(con).to_csv(OUT / "inventory_scenario.csv", index=False)
        for filename in ["sales_summary", "forecast_performance"]:
            con.execute((ROOT / f"sql/{filename}.sql").read_text()).df().to_csv(OUT / f"sql_{filename}.csv", index=False)
