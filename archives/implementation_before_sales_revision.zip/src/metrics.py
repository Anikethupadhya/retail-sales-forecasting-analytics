import numpy as np
import pandas as pd


def score(actual, prediction):
    actual, prediction = np.asarray(actual, dtype=float), np.asarray(prediction, dtype=float)
    if actual.shape != prediction.shape or not np.isfinite(actual).all() or not np.isfinite(prediction).all():
        raise ValueError("Metrics require aligned finite values")
    error = np.abs(actual - prediction)
    denominator = np.abs(actual).sum()
    return {"mae": float(error.mean()), "wape": float(100 * error.sum() / denominator) if denominator else None,
            "absolute_error_sum": float(error.sum()), "actual_units": float(denominator), "observations": len(actual)}


def reduction(baseline, candidate):
    return 100 * (baseline - candidate) / baseline if pd.notna(baseline) and baseline > 0 and pd.notna(candidate) else None


def summaries(predictions):
    overall, products = [], []
    for model, group in predictions.groupby("model", sort=True):
        overall.append({"model": model, **score(group.actual, group.prediction)})
        for pid, part in group.groupby("product_id"):
            products.append({"model": model, "product_id": pid, **score(part.actual, part.prediction)})
    products = pd.DataFrame(products)
    overall = pd.DataFrame(overall)
    base = products[products.model.eq("seasonal_naive")].set_index("product_id").wape
    products["baseline_wape"] = products.product_id.map(base)
    products["relative_wape_reduction_pct"] = [reduction(b, c) for b, c in zip(products.baseline_wape, products.wape)]
    base_pooled = float(overall.loc[overall.model.eq("seasonal_naive"), "wape"].iloc[0])
    for i, row in overall.iterrows():
        part = products[products.model.eq(row.model)]
        comparable = part.wape.notna() & part.baseline_wape.notna()
        beat = comparable & part.wape.lt(part.baseline_wape)
        overall.loc[i, "relative_wape_reduction_pct"] = reduction(base_pooled, row.wape)
        overall.loc[i, "products_beating_baseline"] = int(beat.sum())
        overall.loc[i, "comparable_products"] = int(comparable.sum())
        overall.loc[i, "products_beating_baseline_pct"] = 100 * beat.sum() / comparable.sum() if comparable.sum() else np.nan
        overall.loc[i, "mean_product_wape"] = part.wape.mean()
    return overall, products
