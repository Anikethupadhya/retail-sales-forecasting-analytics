"""Run with python -m src.pipeline. Dashboard never imports this module."""
import hashlib
import importlib.metadata
import json
import platform
import time

import pandas as pd

from .common import ROOT, OUT, load_config, save_json
from .data import prepare
from .forecast import evaluate
from .inventory import build_database
from .metrics import summaries
from .report import generate


def main():
    started = time.time()
    cfg = load_config()
    OUT.mkdir(exist_ok=True)
    # A failed rerun must not leave a stale success marker for the dashboard.
    (OUT / "run_manifest.json").unlink(missing_ok=True)
    print("Auditing the official workbook", flush=True)
    daily, metadata, manifest, audit = prepare(cfg)
    validations = [s for s in manifest["splits"] if s["stage"] == "validation"]
    validation, events = evaluate(daily, validations, cfg["models"], cfg)
    overall, products = summaries(validation)
    validation.to_csv(OUT / "validation_predictions.csv", index=False)
    overall.to_csv(OUT / "validation_overall_metrics.csv", index=False)
    products.to_csv(OUT / "validation_product_metrics.csv", index=False)
    split_metrics = []
    for split, group in validation.groupby("split"):
        summary, _ = summaries(group)
        summary["split"] = split
        split_metrics.append(summary)
    pd.concat(split_metrics).to_csv(OUT / "validation_window_metrics.csv", index=False)
    # Global choice: minimize pooled validation WAPE. Baseline preferred on exact ties.
    overall["tie_priority"] = overall.model.map({m: i for i, m in enumerate(cfg["models"])})
    selected = overall.sort_values(["wape", "tie_priority"]).iloc[0]
    correction_path = OUT / "correction_record.json"
    correction = None
    if correction_path.exists():
        correction = json.loads(correction_path.read_text())
        # Ingestion repair after first execution: keep the original chosen family.
        selected = overall[overall.model.eq(correction["previous_selected_model"])].iloc[0]
    freeze = {"selected_model": selected.model, "selection_metric": "Pooled WAPE across all three validation windows and all selected products",
              "validation_wape": float(selected.wape), "candidate_models": cfg["models"],
              "candidate_settings": {"ses": "Estimated initialization; optimized smoothing level",
                                     "hw_weekly": "Additive weekly seasonality, no trend; optimized coefficients; use_brute=False",
                                     "hw_damped_weekly": "Additive weekly seasonality and damped additive trend; optimized coefficients; use_brute=False"},
              "nonnegative_clipping": cfg["clip_forecasts_at_zero"],
              "failure_policy": "Any exception, nonfinite forecast or optimizer failure falls back to seasonal naive, recorded in model_events.json. Other warnings are retained with predictions.",
              "config_sha256": hashlib.sha256((ROOT / "config.json").read_bytes()).hexdigest(),
              "frozen_before_final_test": True}
    if correction:
        freeze["ingestion_correction"] = "Model family preserved from first validation-only selection; see correction_record.json. The final-test outcomes were already observed before correcting cross-sheet ingestion duplication."
        freeze["selection_metric"] += "; preserved original family after documented ingestion correction"
    save_json(OUT / "frozen_selection.json", freeze)
    print(f"Frozen selection: {selected.model}, validation pooled WAPE {selected.wape:.3f}%", flush=True)
    # Only the selected model and the baseline receive final-test evaluation.
    test_models = list(dict.fromkeys(["seasonal_naive", selected.model]))
    test, test_events = evaluate(daily, [manifest["splits"][-1]], test_models, cfg)
    test_overall, test_products = summaries(test)
    test.to_csv(OUT / "test_predictions.csv", index=False)
    test_overall.to_csv(OUT / "test_overall_metrics.csv", index=False)
    test_products.to_csv(OUT / "test_product_metrics.csv", index=False)
    forecasts = pd.concat([validation, test], ignore_index=True)
    forecasts["selected"] = forecasts.model.eq(selected.model)
    build_database(daily, metadata, forecasts, manifest)
    save_json(OUT / "model_events.json", events + test_events)
    save_json(OUT / "run_manifest.json", {"python": platform.python_version(),
              "packages": {p: importlib.metadata.version(p) for p in ["pandas", "numpy", "duckdb", "statsmodels", "scipy", "plotly", "streamlit", "openpyxl", "pyarrow"]},
              "duration_seconds": round(time.time() - started, 2), "raw_sha256": audit["sha256"],
              "config_sha256": freeze["config_sha256"], "completed": True})
    generate()
    print(test_overall.to_string(index=False), flush=True)
    print(f"Analysis completed in {time.time() - started:.1f}s. Outputs: {OUT}", flush=True)


if __name__ == "__main__":
    main()
