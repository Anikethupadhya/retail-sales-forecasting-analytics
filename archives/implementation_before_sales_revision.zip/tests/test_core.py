import json

import duckdb
import numpy as np
import pandas as pd
import pytest

from src.common import OUT, load_config
from src.data import make_splits, cross_sheet_replicas
from src.forecast import evaluate, seasonal_naive
from src.inventory import scenario
from src.metrics import reduction, score, summaries


def test_split_boundaries():
    cfg = load_config()
    splits = make_splits(pd.Timestamp("2009-12-01"), pd.Timestamp("2011-12-08"), cfg)
    assert len(splits) == 4
    for i, split in enumerate(splits):
        assert pd.Timestamp(split["train_end"]) + pd.Timedelta(days=1) == pd.Timestamp(split["forecast_start"])
        assert (pd.Timestamp(split["forecast_end"]) - pd.Timestamp(split["forecast_start"])).days == 27
        assert split["training_days"] >= 365
        if i:
            assert pd.Timestamp(splits[i-1]["forecast_end"]) + pd.Timedelta(days=1) == pd.Timestamp(split["forecast_start"])
    assert splits[-1]["forecast_end"] == "2011-12-08"


def test_baseline_repeats_origin_week():
    expected = np.tile([1, 2, 3, 4, 5, 6, 7], 4)
    np.testing.assert_array_equal(seasonal_naive([999] * 30 + [1, 2, 3, 4, 5, 6, 7], 28), expected)


def test_cross_sheet_replicas_preserve_repeated_lines_and_missing_values():
    raw = pd.DataFrame({"Invoice": [1] * 7, "Quantity": [5, 5, 5, 5, 5, 6, 5],
                        "Customer ID": [np.nan] * 7, "source_sheet": ["a", "a", "b", "b", "b", "b", "a"],
                        "excel_row": range(2, 9)})
    replica = cross_sheet_replicas(raw)
    # Three occurrences in each sheet match; different quantities never match.
    assert replica.tolist() == [False, False, True, True, False, False, True]
    kept = raw[~replica]
    assert (kept.Quantity == 5).sum() == 3
    assert (kept.Quantity == 6).sum() == 1


@pytest.mark.parametrize("model", ["seasonal_naive", "ses", "hw_weekly", "hw_damped_weekly"])
def test_future_actuals_cannot_change_forecast(model):
    cfg = load_config()
    dates = pd.date_range("2020-01-01", periods=428)
    sales = pd.DataFrame({"product_id": "12345", "date": dates, "units": np.tile(np.arange(1, 8), 62)[:428]})
    split = {"split": "test_probe", "stage": "test", "train_end": str(dates[399].date()),
             "forecast_start": str(dates[400].date()), "forecast_end": str(dates[-1].date())}
    before, _ = evaluate(sales, [split], [model], cfg)
    sales.loc[400:, "units"] = 100000
    after, _ = evaluate(sales, [split], [model], cfg)
    np.testing.assert_array_equal(before.prediction, after.prediction)
    assert not np.array_equal(before.actual, after.actual)


def test_metrics_and_zero_denominators():
    measured = score([10, 0, 20], [8, 4, 24])
    assert measured["mae"] == pytest.approx(10 / 3)
    assert measured["wape"] == pytest.approx(100 / 3)
    assert score([0, 0], [1, 1])["wape"] is None
    assert reduction(50, 60) == pytest.approx(-20)
    assert reduction(0, 0) is None
    with pytest.raises(ValueError):
        score([1], [np.nan])


def test_pooled_wape_is_not_mean_product_wape():
    rows = []
    for model in ["seasonal_naive", "ses"]:
        rows += [{"model": model, "product_id": "a", "actual": 100, "prediction": 90},
                 {"model": model, "product_id": "b", "actual": 1, "prediction": 0}]
    overall, _ = summaries(pd.DataFrame(rows))
    assert overall.iloc[0].wape == pytest.approx(1100 / 101)
    assert overall.iloc[0].mean_product_wape == 55


def test_inventory_sql_hand_calculation():
    with duckdb.connect() as con:
        con.execute("CREATE TABLE product_metadata(product_id VARCHAR, description VARCHAR)")
        con.execute("INSERT INTO product_metadata VALUES ('a', 'Example')")
        con.execute("CREATE TABLE inventory_assumptions(product_id VARCHAR, base_lead_days INTEGER, base_inventory_units DOUBLE, assumption_type VARCHAR)")
        con.execute("INSERT INTO inventory_assumptions VALUES ('a', 2, 15, 'SIMULATED')")
        con.execute("CREATE TABLE forecasts(product_id VARCHAR, origin DATE, date DATE, prediction DOUBLE, selected BOOLEAN, stage VARCHAR, horizon_day INTEGER)")
        con.execute("INSERT INTO forecasts SELECT 'a', DATE '2020-01-01', DATE '2020-01-01' + CAST(i AS INTEGER), 10, TRUE, 'test', i FROM range(1,29) r(i)")
        base = scenario(con).iloc[0]
        assert base.forecast_lead_time_units == 20
        assert base.scenario_shortfall_units == 5
        assert base.replenishment_flag
        delayed = scenario(con, delay=1).iloc[0]
        assert delayed.scenario_shortfall_units == 15
        assert scenario(con, multiplier=2).iloc[0].scenario_shortfall_units == 0
        assert scenario(con, extra_units=5).iloc[0].scenario_shortfall_units == 0
        assert scenario(con, delay=26).iloc[0].days_covered == 28
        with pytest.raises(ValueError):
            scenario(con, delay=27)


@pytest.mark.skipif(not (OUT / "run_manifest.json").exists(), reason="Run full pipeline first")
def test_saved_analysis_integrity():
    audit = json.loads((OUT / "data_audit.json").read_text())
    manifest = json.loads((OUT / "split_manifest.json").read_text())
    freeze = json.loads((OUT / "frozen_selection.json").read_text())
    assert sum(audit["exclusive_exclusion_counts_in_priority_order"].values()) + audit["retained_rows"] == audit["raw_rows"]
    assert len(audit["sheets"]) == 2
    assert len(manifest["selected_product_ids"]) == 20
    eligible = pd.read_csv(OUT / "product_eligibility.csv", dtype={"product_id": str})
    assert eligible.loc[eligible.selected, "eligible"].all()
    assert pd.to_datetime(eligible.first_sale).max() < pd.Timestamp(manifest["selection_cutoff_exclusive"])
    for stage in ["validation", "test"]:
        predictions = pd.read_csv(OUT / f"{stage}_predictions.csv", dtype={"product_id": str})
        dates = pd.to_datetime(predictions.date)
        origin = pd.to_datetime(predictions.origin)
        assert (dates > origin).all()
        assert ((dates - origin).dt.days == predictions.horizon_day).all()
        assert predictions.groupby(["split", "product_id", "model"]).size().eq(28).all()
        assert predictions.prediction.ge(0).all()
        assert predictions.train_last_date.eq(predictions.origin).all()
        actual_overall, _ = summaries(predictions)
        saved = pd.read_csv(OUT / f"{stage}_overall_metrics.csv").set_index("model")
        for _, row in actual_overall.iterrows():
            assert saved.loc[row.model, "wape"] == pytest.approx(row.wape)
    with duckdb.connect(str(OUT / "retail.duckdb"), read_only=True) as con:
        result = scenario(con, delay=3, multiplier=0.5)
        assert len(result) == 20
        assert (result.days_covered == result.lead_days).all()
        for _, row in result.iterrows():
            independent = con.execute("SELECT SUM(prediction) FROM forecasts WHERE product_id=? AND selected AND stage='test' AND horizon_day<=?", [row.product_id, int(row.lead_days)]).fetchone()[0]
            assert row.forecast_lead_time_units == pytest.approx(independent)
    assert freeze["frozen_before_final_test"]
