from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from src.common import ROOT, OUT


@pytest.mark.skipif(not (OUT / "run_manifest.json").exists(), reason="Run full pipeline first")
def test_dashboard_load_and_controls():
    app = AppTest.from_file(str(ROOT / "app.py")).run(timeout=60)
    assert len(app.exception) == 0
    assert len(app.metric) >= 7
    assert len(app.dataframe) >= 7
    before = app.metric[4].value
    app.sidebar.slider[0].set_value(17)
    app.sidebar.slider[1].set_value(0)
    app.sidebar.selectbox[0].select_index(1)
    app.run(timeout=60)
    assert len(app.exception) == 0
    assert app.metric[4].value == "20"
    app.sidebar.slider[1].set_value(200)
    app.sidebar.number_input[0].set_value(100000)
    app.run(timeout=60)
    assert len(app.exception) == 0
    assert app.metric[4].value == "0"
