# Retail Demand Forecasting & Inventory Risk Analytics

A reproducible Python portfolio project that forecasts daily positive merchandise
units, benchmarks 28-day fixed-origin predictions, and explores simulated
replenishment scenarios in DuckDB SQL and a Streamlit dashboard.

**Measured result:** the validation-selected `hw_weekly` approach achieved
**80.24% pooled final-test WAPE**, versus **112.80%** for the
weekly seasonal-naive baseline: **28.86% relative WAPE reduction**.
It beat the baseline on **10/20 products (50%)**.
The absolute errors remain large. These figures describe historical observed-sales
forecast performance, not accuracy, operational savings or calibrated inventory risk.

## Reproduce

Tested with Python 3.14.3 on Windows. Run these commands from this folder:

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements.txt
.\.venv\Scripts\python -m src.pipeline
.\.venv\Scripts\python -m pytest -q --junitxml=outputs/test-results.xml
.\.venv\Scripts\python -m streamlit run app.py --server.headless true --browser.gatherUsageStats false
```

**The full analysis command is `python -m src.pipeline`** (use the virtual environment's
Python). It downloads the official workbook if needed, audits it, selects products,
validates candidates, evaluates the frozen approach, creates saved outputs and the
DuckDB database, and regenerates this README and the evidence document from measured
results. The latest measured execution took 49.5 seconds,
with runtime varying by hardware and first-run workbook reads. Subsequent runs use
a raw-file-checksum-keyed Parquet cache. The dashboard only reads saved results and
runs scenario SQL; it does not train models. Open http://localhost:8501.

If source download fails, follow [exact manual instructions](docs/data-download.md).
`data/raw/`, read caches and the generated DuckDB binary stay outside Git. Rebuild
the database by running the pipeline after cloning. Dependencies and their installed
transitive versions are pinned in `requirements.txt`; environment provenance is saved.

## Source and audit

[Chen, D. (2012), Online Retail II, UCI](https://archive.ics.uci.edu/dataset/502/online+retail+ii),
[DOI:10.24432/C5CG6D](https://doi.org/10.24432/C5CG6D), CC BY 4.0.
The actual workbook contains **1,067,371 rows** across sheets
`Year 2009-2010` (525,461) and `Year 2010-2011`
(541,910). Raw timestamps range from
**2009-12-01 07:45:00** to **2011-12-09 12:50:00**. Actual columns are
`Invoice`, `StockCode`, `Description`, `Quantity`, `InvoiceDate`, `Price`,
`Customer ID`, `Country`. Both sheets are inspected explicitly.

SHA-256: `bcbe73b35f5b7babf197fb0cb983a11f5d9ff929078d4aa53d171b1f2df2e980`.

Exclusive exclusions are counted in this priority order, so they reconcile:

| exclusion | rows |
| --- | --- |
| invalid_date | 0 |
| missing_product_or_invoice | 0 |
| cross_sheet_replica | 22523 |
| cancellation_invoice | 19165 |
| negative_quantity | 3393 |
| zero_or_invalid_quantity | 0 |
| non_product_code | 4769 |
| nonpositive_or_invalid_price | 2576 |
| final_incomplete_day | 1618 |

**1,013,327 merchandise rows remain** before selecting the cohort.
The workbook has 34,335 exact repeated rows
beyond their first occurrence. Remove **22,523 cross-sheet
replicas** in the overlapping December 2010 export interval, matching every original
field plus its within-sheet occurrence number. Retain **11,812
within-sheet repeated lines**: no unique line ID proves these are errors.
Missing customer IDs alone do not exclude sales; **225,752 retained
rows have no customer ID**. Returns/cancellations and all excluded rows are preserved
separately in local compressed CSV audit extracts with sheet and Excel row references.

Merchandise IDs match five digits with up to two trailing letters, explicitly
excluding charges such as postage, discounts and manual adjustments. This heuristic
may also exclude unusual genuine merchandise codes. Nonpositive prices are excluded
as noncommercial/adjustment records. Missing descriptions are audited, not an automatic
exclusion. All countries are pooled. No outlier trimming is applied.

The latest timestamp is midday on 2011-12-09, so that entire potentially incomplete
day is excluded. Daily grids run from 2009-12-01 to 2011-12-08.
Absent product-date records become zero observed sales, including closures and short
pre-listing intervals. Missing transactions, no demand and stock-outs cannot be distinguished.
Positive sales are a proxy for demand; the workbook does not reveal lost sales.

## Cohort, forecasts and model selection

Select 20 products using only data strictly before **2011-08-19**:
first sale within 90 days of the grid start, sales on at least 25% of initial calendar
days and 30% of the last 90 days. Rank eligible products by initial positive units,
breaking ties by ascending ID. Save all eligibility decisions and selected IDs.
The initial training window contains **626 days**.

| split | train_start | train_end | forecast_start | forecast_end | training_days |
| --- | --- | --- | --- | --- | --- |
| validation_1 | 2009-12-01 | 2011-08-18 | 2011-08-19 | 2011-09-15 | 626 |
| validation_2 | 2009-12-01 | 2011-09-15 | 2011-09-16 | 2011-10-13 | 654 |
| validation_3 | 2009-12-01 | 2011-10-13 | 2011-10-14 | 2011-11-10 | 682 |
| final_test | 2009-12-01 | 2011-11-10 | 2011-11-11 | 2011-12-08 | 710 |

The seasonal-naive baseline repeats the origin's last seven calendar-day observations
throughout the horizon. Candidates are simple exponential smoothing (`ses`), additive
weekly seasonality without trend (`hw_weekly`), and additive weekly seasonality with
damped additive trend (`hw_damped_weekly`). Statsmodels estimates initialization and
optimizes smoothing parameters on each available training history. Weekly models use
`use_brute=False`. Forecasts are prespecified to be clipped at zero. Exceptions,
nonfinite forecasts and optimizer failures fall back to the baseline, with events saved.

Choose one global model family by minimum pooled WAPE over the three validation
windows, with baseline preferred on ties. Each model sees only dates through its
origin. No actual observation inside its forecast horizon influences later predictions.
The frozen selection artifact is written before final-test prediction. Only the chosen
family and baseline receive final-test evaluation. Candidate failures and negative
improvements are preserved. This run recorded 76 model events: 2
fallback fits, 2 fits with warnings, and 332 individual predictions clipped at zero.

**Data correction disclosure:** the first run retained replicas across overlapping
workbook sheets. After discovering the overlap, ingestion was repaired and rerun
with the **original validation-selected family and all model settings fixed**.
The first test was already observed before that repair; the corrected figures are
not a newly untouched holdout. Original measured outputs are preserved in
`outputs/before_overlap_correction/`, with rationale in `outputs/correction_record.json`.
No model family was chosen or tuned based on final-test improvement.

## Actual benchmark results

Validation (all three windows pooled, 1,680 product-days per model):

| model | mae | wape | relative_wape_reduction_pct | products_beating_baseline | mean_product_wape |
| --- | --- | --- | --- | --- | --- |
| hw_damped_weekly | 74.93 | 100.70 | 16.36 | 11.00 | 124.24 |
| hw_weekly | 73.80 | 99.19 | 17.62 | 11.00 | 122.53 |
| seasonal_naive | 89.58 | 120.39 | 0.00 | 0.00 | 133.88 |
| ses | 80.15 | 107.72 | 10.53 | 10.00 | 131.46 |

Final test (560 product-days per evaluated model):

| model | mae | wape | relative_wape_reduction_pct | products_beating_baseline | mean_product_wape |
| --- | --- | --- | --- | --- | --- |
| hw_weekly | 68.81 | 80.24 | 28.86 | 10.00 | 104.01 |
| seasonal_naive | 96.73 | 112.80 | 0.00 | 0.00 | 108.73 |

WAPE = `100 × sum(abs(actual − prediction)) / sum(abs(actual))`.
MAE is units per product-day. `wape` in the overall table is **pooled WAPE**;
`mean_product_wape` is the arithmetic mean of defined per-product WAPEs.
Relative reduction = `100 × (baseline WAPE − model WAPE) / baseline WAPE`.
Zero actual denominators yield null/blank WAPE; zero baseline WAPE yields null
relative reduction. Product wins require strictly lower WAPE, using only comparable
defined denominators. WAPE can exceed 100%; **100 minus WAPE is not accuracy**.
Validation and final-test predictions, pooled metrics and product metrics are separate.

## SQL and inventory scenarios

DuckDB tables: `daily_sales`, `forecasts`, `product_metadata`, `inventory_assumptions`.
Standalone [SQL](sql/) demonstrates aggregation, joins, `ROW_NUMBER`, rolling seven-day
sales and cumulative forecast windows. Scenario controls are bound SQL parameters.

**Simulated assumptions:** sorted product IDs deterministically receive 5–11 day
base lead times and starting stock equal to rounded `7 × initial mean daily units × factor`,
with factors cycling through 0.75, 1.00 and 1.25. Initial means use only pre-validation
data. Users can add 0–17 days supplier delay, vary stock by 0–200% and add units.
Total lead times remain within 28 days. Forecast sales over lead time minus scenario
stock, floored at zero, defines shortfall. A positive shortfall triggers a scenario
replenishment indicator. No intervening receipts or safety stock are assumed.

The default scenario flags **7/20 products**.
This is a retrospective scenario at the final-test forecast origin, not a current
operational forecast. **Stock and supplier inputs are simulated**, not measured.
Flags are not calibrated stock-out probabilities and do not establish actual savings.

## Dashboard

Product selection, coverage, history, shaded evaluation periods, baseline versus
selected forecasts, overall and product metrics, source audit, and responsive inventory
controls all use saved outputs. The screenshot images below show the tested default
state. Measured forecasting results and simulated inventory are labeled separately.

![Measured sales and forecasts](docs/screenshots/dashboard-sales.png)
![Simulated inventory scenarios](docs/screenshots/dashboard-inventory.png)

## Verification and repository map

`python -m pytest -q --junitxml=outputs/test-results.xml` checks chronological split
boundaries, weekly baseline repetition, future-actual perturbations for all model
families, exact cross-sheet occurrence matching, metric arithmetic and zero denominators,
pooled versus mean WAPE, hand-calculated SQL scenarios and horizon limits, saved-output
reconciliation, and Streamlit load/product/delay/inventory interactions.
The browser smoke result and screenshots are recorded separately in
`outputs/browser_smoke.json`. Screenshots use a development-only Playwright utility
with local Edge; Playwright is not a dashboard runtime dependency.

- `config.json`: prespecified data, eligibility, horizon and model rules.
- `src/`: acquisition/audit, forecasting, metrics, SQL inventory, orchestration and reporting.
- `sql/`: three independently readable query files.
- `app.py`: dashboard reading saved outputs; `tests/`: meaningful checks.
- `outputs/`: audit, selection/split manifests, forecasts, metrics, assumptions and execution evidence.
- `docs/interview-guide.md`: decisions and explanations for interviews.
- `docs/resume-evidence.md`: numerical claims mapped to measured artifacts.

Raw data, caches, customer-level audit extracts and the generated database are ignored.
No remote repository, cloud service or public deployment was created.

## Limitations and extensions

This is a high-volume cohort, not the full product catalogue, and the final holdout
falls near a holiday peak. Substantial product-level errors and only 10/20 wins
limit the pooled headline. There are no actual stock levels, deliveries, promotions,
lost-sales labels or calibrated forecast intervals. Returns are separate rather than
net sales. Wholesale spikes remain in the target. Zero-filled days and the merchandise
code heuristic are measurement assumptions. The ingestion repair is disclosed above.
The optional Prophet extension is deferred; no LSTM, Docker, paid API or forecasting
agent is used. A future comparison should prespecify new holdouts before testing.

## Proposed resume entry

**Retail Demand Forecasting & Inventory Risk Analytics**

- Reduced pooled 28-day forecast WAPE by 28.9% versus a weekly seasonal-naive baseline (112.8% to 80.2%) across 20 retail products using Python, pandas and statsmodels; selected settings on three chronological validation windows.
- Audited 1,067,371 UCI transaction rows and built a DuckDB SQL and Streamlit/Plotly dashboard with product-level metrics and adjustable, explicitly simulated inventory and supplier-delay scenarios.

These are portfolio benchmark claims; do not describe the inventory scenarios as
operational outcomes. See the [claim-by-claim evidence](docs/resume-evidence.md).
