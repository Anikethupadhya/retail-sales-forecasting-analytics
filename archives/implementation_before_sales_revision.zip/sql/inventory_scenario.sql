-- Parameters: supplier delay days, inventory multiplier, extra units per product.
-- Historical final-test-origin scenario. All inventory/supplier inputs are simulated.
WITH controls AS (
    SELECT CAST(? AS INTEGER) AS delay_days, CAST(? AS DOUBLE) AS inventory_multiplier,
           CAST(? AS DOUBLE) AS extra_units
), timeline AS (
    SELECT f.product_id, f.origin, f.date, f.prediction,
           ROW_NUMBER() OVER (PARTITION BY f.product_id ORDER BY f.date) AS forecast_day,
           SUM(f.prediction) OVER (PARTITION BY f.product_id ORDER BY f.date
               ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_forecast_units
    FROM forecasts f WHERE f.selected AND f.stage = 'test'
), lead_sales AS (
    SELECT t.product_id, MAX(t.origin) AS scenario_origin,
           MAX(t.cumulative_forecast_units) AS forecast_lead_time_units,
           COUNT(*) AS days_covered
    FROM timeline t JOIN inventory_assumptions a USING (product_id) CROSS JOIN controls c
    WHERE t.forecast_day <= a.base_lead_days + c.delay_days
    GROUP BY t.product_id
), joined AS (
    SELECT p.product_id, p.description, l.scenario_origin,
           a.assumption_type, a.base_lead_days + c.delay_days AS lead_days,
           l.days_covered, a.base_inventory_units * c.inventory_multiplier + c.extra_units AS scenario_inventory_units,
           l.forecast_lead_time_units
    FROM lead_sales l JOIN product_metadata p USING (product_id)
    JOIN inventory_assumptions a USING (product_id) CROSS JOIN controls c
)
SELECT *, GREATEST(forecast_lead_time_units - scenario_inventory_units, 0) AS scenario_shortfall_units,
       forecast_lead_time_units > scenario_inventory_units AS replenishment_flag
FROM joined ORDER BY scenario_shortfall_units DESC, product_id;
