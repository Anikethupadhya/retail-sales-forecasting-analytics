-- Aggregation over observed positive sales; rolling window includes zero-sales dates.
WITH rolling AS (
    SELECT product_id, date, units,
           SUM(units) OVER (PARTITION BY product_id ORDER BY date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS units_last_7_days
    FROM daily_sales
)
SELECT r.product_id, p.description, SUM(r.units) AS observed_units,
       AVG(r.units) AS average_daily_units, MAX(r.units_last_7_days) AS peak_7_day_units,
       SUM(CASE WHEN r.units > 0 THEN 1 ELSE 0 END) AS active_days
FROM rolling r JOIN product_metadata p USING (product_id)
GROUP BY r.product_id, p.description ORDER BY observed_units DESC;
