-- Pooled WAPE is a ratio of sums, not the average of per-product percentages.
SELECT stage, model, COUNT(*) AS observations, AVG(ABS(actual - prediction)) AS mae,
       100.0 * SUM(ABS(actual - prediction)) / NULLIF(SUM(ABS(actual)), 0) AS pooled_wape
FROM forecasts GROUP BY stage, model ORDER BY stage, pooled_wape;
